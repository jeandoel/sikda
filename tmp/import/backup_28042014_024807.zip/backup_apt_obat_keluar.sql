"udn","P1704020201","2014-04-22 00:00:00","-","PUSKESMAS","APT","Apotik Puskesmas LINAU","8500","lengkap","gudanglinau","2014-04-22 13:22:07",\N,\N,"0",\N
"udn01","P1704020201","2014-04-22 00:00:00","-","PUSKESMAS","APT","Apotik Puskesmas LINAU","100","-","gudanglinau","2014-04-22 14:50:07",\N,\N,"0",\N
"udn02","P1704020201","2014-04-22 00:00:00","-","PUSKESMAS","APT","Apotik Puskesmas LINAU","100","-","gudanglinau","2014-04-22 14:54:57",\N,\N,"0",\N
"ud","P1704020201","2014-04-22 00:00:00","123","PUSKESMAS","APT","Apotik Puskesmas LINAU","500","lengkap","gudanglinau","2014-04-22 11:54:44",\N,\N,"0",\N
"udn03","P1704020201","2014-04-22 00:00:00","-","PUSKESMAS","APT","Apotik Puskesmas LINAU","100","-","gudanglinau","2014-04-22 14:56:35",\N,\N,"0",\N
"udin","P1704020201","2014-04-23 00:00:00","-","PUSKESMAS","APT","Apotik Puskesmas LINAU","500","-","all","2014-04-23 08:57:58",\N,\N,"0",\N
"a1","P1704020201","2014-04-23 00:00:00","-","PUSKESMAS","APT","Apotik Puskesmas LINAU","500","-","all","2014-04-23 09:16:59",\N,\N,"0",\N
"234","P1704020201","2014-04-23 00:00:00","-","PUSKESMAS","APT","Apotik Puskesmas LINAU","500","-","all","2014-04-23 09:27:22",\N,\N,"0",\N
