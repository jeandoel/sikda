"1","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"PUSTU","P1704020201-1","PUSTU KEDUNGWARINGIN CERIA",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"2","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"POLINDES","P1704020201-2","POLINDAS ABADI",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"3","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"PUSLIN","P1704020201-3","PUSLING HEBAT",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"4","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"BIDAN","P1704020201-4","Bdn. Fulan",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"5","P1704020201","LINAU","Ds. Benteng Harapan, Kec. Maje","RSM","12345","17","1704","1704020",\N,"PUSKESMAS","P1704020201-5",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"-","-","-","all","2013-06-13",\N,\N
"6",\N,"",\N,\N,\N,"17","1704",\N,\N,"KABUPATEN",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","all","2013-07-02",\N,\N
"7","P1704041202","LUAS","Kec. Luas","AGS","NIP33","17","1704","1704041",\N,"PUSKESMAS","P1704020201-6",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","all","2013-07-02",\N,\N
"8","P3276010201","SAWANGAN","Jl. Raya Muchtar No. 155 Rt. 03/03, Kec. Sawangan","Asep S","NI334","32","3276","3276010",\N,"PUSKESMAS","-7",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"-","-","-","alldepok","2014-04-07",\N,\N
"9",\N,"",\N,\N,\N,"32","3276",\N,\N,"KABUPATEN",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"-","-","-","alldepok","2014-04-07",\N,\N
"10","P3522080101","KEDUNGADEM","Ds. Kedungadem, Kec. Kedungadem","opick","11223344","35","3522","3522080",\N,"PUSKESMAS","P3522080101-7",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","allkdm","2014-04-17",\N,\N
"11",\N,"",\N,\N,\N,"35","3522",\N,\N,"KABUPATEN",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"iu","o","p","allkdm","2014-04-17",\N,\N
"12","P3522080202","KESONGO","Ds. Kesongo, Kec. Kedungadem","POICK","98797","35","3522","3522080",\N,"PUSKESMAS","P3522080202-8",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","allkesongo","2014-04-17",\N,\N
"13",\N,"",\N,\N,\N,"11","1112",\N,\N,"KABUPATEN",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"-","-","-","allaceh","2014-04-28",\N,\N
"14","P1112060201","BABAH ROT","Ds. Pantee Rakyat, Kec. Babah Rot","Opvcik","123123","11","1112","1112060",\N,"PUSKESMAS","P1112060201-9",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","allaceh","2014-04-28",\N,\N
