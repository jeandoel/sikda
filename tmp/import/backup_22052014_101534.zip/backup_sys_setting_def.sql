"1","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"PUSTU","P1704020201-1","PUSTU KEDUNGWARINGIN CERIA",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"2","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"POLINDES","P1704020201-2","POLINDAS ABADI",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"3","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"PUSLIN","P1704020201-3","PUSLING HEBAT",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"4","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"BIDAN","P1704020201-4","Bdn. Fulan",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"5","P1704020201","LINAU","Ds. Benteng Harapan, Kec. Maje","RSM","12345","17","1704","1704020",\N,"PUSKESMAS","P1704020201-5",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"-","-","-","all","2013-06-13",\N,\N
"6",\N,"",\N,\N,\N,"17","1704",\N,\N,"KABUPATEN",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","all","2013-07-02",\N,\N
"7","P1704041202","LUAS","Kec. Luas","AGS","NIP33","17","1704","1704041",\N,"PUSKESMAS","P1704020201-6",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","all","2013-07-02",\N,\N
"8","P1107062201","DRIEN RAMPAK","Jl. Meulaboh - Banda Aceh, Kec. Arongan Lambalek","andi","12398132","11","1107","1107062",\N,"PUSKESMAS","P1107062201-7",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","allaceh","2014-04-29","allaceh","2014-05-02 03:21:18"
"9",\N,"",\N,\N,\N,"11","1107",\N,\N,"KABUPATEN",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","allaceh","2014-04-29",\N,\N
"10","P3514150101","BANGIL","Jl. Mangga 548, Kec. Bangil","taufiqurohman","12311989","35","3514","3514150",\N,"PUSKESMAS","P3514150101-8",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","allpasuruan","2014-05-22",\N,\N
