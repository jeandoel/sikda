"1704","KABUPATEN","2","1",\N,"KABUPATEN","0",\N,"0","kaur","2014-12-03"
"1704","KABUPATEN","6","10",\N,"KABUPATEN","0",\N,"0","kaur","2014-12-03"
"P1704020201","PUSKESMAS","6","0",\N,"PKM","0",\N,"0","all","2014-12-03"
