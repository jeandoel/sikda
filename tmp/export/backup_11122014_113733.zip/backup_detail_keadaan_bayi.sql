"1","1","Segera Menangis"
