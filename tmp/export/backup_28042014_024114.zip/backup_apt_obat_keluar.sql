"wew","P1704020201","2014-02-28 00:00:00","923u","PUSKESMAS","APT","Apotik Puskesmas LINAU","10","asd","all","2014-02-28 14:41:49",\N,\N,"0",\N
"sdfsdlk999","P1704020201","2014-03-06 00:00:00","0q9ue9","PUSKESMAS","APT","Apotik Puskesmas LINAU","55","lksad","all","2014-03-06 10:45:49",\N,\N,"0",\N
"874jh","P1704020201","2014-03-06 00:00:00","kiusdhf98","PUSKESMAS","APT","Apotik Puskesmas LINAU","5","sifgd","all","2014-03-06 11:03:03",\N,\N,"0",\N
"sdflkj","P1704020201","2014-04-16 00:00:00","934","PUSKESMAS","APT","Apotik Puskesmas LINAU","50","asd","all","2014-04-16 14:06:41",\N,\N,"0",\N
"568790u-","3522","2014-04-17 00:00:00","tfghj","KABUPATEN","PUSKESMAS","P3522080101","100","uyiop[","kabbjn","2014-04-17 03:15:56",\N,\N,"0",\N
"34567","P3522080101","2014-04-17 00:00:00","wer","PUSKESMAS","APT","Apotik Puskesmas KEDUNGADEM","95","wes","allkdm","2014-04-17 03:22:26",\N,\N,"0",\N
"de5fr","P3522080101","2014-04-17 00:00:00","fr6gt","PUSKESMAS","APT","Apotik Puskesmas KEDUNGADEM","2","99","allkdm","2014-04-17 04:02:43",\N,\N,"0",\N
"678","P3522080202","2014-04-17 00:00:00","5678","PUSKESMAS","APT","Apotik Puskesmas KESONGO","50","POS","allkesongo","2014-04-17 12:11:38",\N,\N,"0",\N
"jasd","P3522080202","2014-04-17 00:00:00","234","PUSKESMAS","APT","Apotik Puskesmas KESONGO","50","tka","allkesongo","2014-04-17 12:15:09",\N,\N,"0",\N
"5678","P3522080101","2014-04-17 00:00:00","tfy","PUSKESMAS","APT","Apotik Puskesmas KEDUNGADEM","3","998","allkdm","2014-04-17 12:49:22",\N,\N,"0",\N
"6781","P1704020201","2014-04-27 00:00:00","yu","PUSKESMAS","APT","Apotik Puskesmas LINAU","10","an","all","2014-04-27 22:45:03",\N,\N,"0",\N
"3456789","P1704020201","2014-04-27 00:00:00","tyuijo","PUSKESMAS","APT","Apotik Puskesmas LINAU","1","sad","all","2014-04-27 22:49:01",\N,\N,"0",\N
