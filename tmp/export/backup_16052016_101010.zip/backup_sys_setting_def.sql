"1",\N,"",\N,\N,\N,"31","3171",\N,\N,"KABUPATEN",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","PUSKESMAS","2015-06-19",\N,\N
"3",\N,"",\N,\N,\N,"14","1402",\N,\N,"KABUPATEN",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"-","-","-","admkab","2016-05-16",\N,\N
"4","P1402010101","PARANAP","Jl. Pasar Peranap, Kec. Peranap","budi mulya","1978464545454","14","1402","1402010",\N,"PUSKESMAS","P1402010101-1",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"-","-","-","admpkm","2016-05-16",\N,\N
