"klr","P1402010101","1402","2016-05-16 00:00:00","001","PUSKESMAS","APT","Apotik Puskesmas PARANAP","200","ok","admpkm","2016-05-16 21:37:15",\N,\N,"0",\N
