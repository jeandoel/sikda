"wew","P1704020201","2014-02-28 00:00:00","923u","PUSKESMAS","APT","Apotik Puskesmas LINAU","10","asd","all","2014-02-28 14:41:49",\N,\N,"0",\N
"sdfsdlk999","P1704020201","2014-03-06 00:00:00","0q9ue9","PUSKESMAS","APT","Apotik Puskesmas LINAU","55","lksad","all","2014-03-06 10:45:49",\N,\N,"0",\N
"874jh","P1704020201","2014-03-06 00:00:00","kiusdhf98","PUSKESMAS","APT","Apotik Puskesmas LINAU","5","sifgd","all","2014-03-06 11:03:03",\N,\N,"0",\N
