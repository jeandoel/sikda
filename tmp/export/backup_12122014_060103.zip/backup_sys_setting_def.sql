"1","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"PUSTU","P1704020201-1","PUSTU KEDUNGWARINGIN CERIA",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"2","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"POLINDES","P1704020201-2","POLINDAS ABADI",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"3","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"PUSLIN","P1704020201-3","PUSLING HEBAT",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"4","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin",\N,\N,"32","3216","3216050",\N,"BIDAN","P1704020201-4","Bdn. Fulan",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"all","2013-06-12",\N,\N
"5","P1704020201","LINAU","Ds. Benteng Harapan, Kec. Maje","RSM","12345","17","1704","1704020",\N,"PUSKESMAS","P1704020201-5",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"-","-","-","all","2013-06-13","all","2014-10-20 04:00:58"
"6",\N,"",\N,\N,\N,"17","1704",\N,\N,"KABUPATEN",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","all","2013-07-02",\N,\N
"7","P1704041202","LUAS","Kec. Luas","AGS","NIP33","17","1704","1704041",\N,"PUSKESMAS","P1704020201-6",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","all","2013-07-02",\N,\N
"8","P3216050201","KEDUNGWARINGIN","Jl. Kedung Gede No. 57 Kec. Kedungwaringin","ASD","ASD","32","3216","3216050",\N,"PUSKESMAS","P3216050201-7",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","bidanall","2014-10-13",\N,\N
"9","P1704020192","MAJE","1231","Asep S","NI334","17","1704","1704020",\N,"PUSKESMAS","P1704020201-8",\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,"","","","all","2014-10-20",\N,\N
